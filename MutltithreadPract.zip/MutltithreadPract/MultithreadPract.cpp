/*
 * MultithreadPract.cpp
 *
 *  Created on: Nov 2, 2025
 *      Author: Aerionna Stephenson
 *
 *      This program creates 2 threads by creating two functions and using the .join
 *      method to  determine the order of execution for the two threads. One thread
 *      counts up to 20 while the other counts down from 20 until it reaches 0.
 */


#include <iostream>
#include <thread>
#include <chrono>  // sleep

/*This is thread 1 that counts up to 20 while a second is places in between
 * each output
 */
void countUp() {
    for (int i = 0; i < 21; i += 1) {
        std::cout << i << std::endl;
        std::this_thread::sleep_for(std::chrono::milliseconds(1000)); //puts a second between each output
    }
}

/*This is thread 1 that counts down from 20 while a second is places in between
 * each output
 */
void countdown() {
    for (int i = 20; i >= 0; i--) {
        std::cout << i << std::endl;
        std::this_thread::sleep_for(std::chrono::milliseconds(1000)); //puts a second between each output
    }
}

int main() {
    // new thread object is assigned to countUp
    std::thread countToTwenty(countUp);

    // Waits for thread 1 to finish before thread 2 begins
    countToTwenty.join();  // <-main waits for thread 1 to finish completely

    // new thread object is assigned to countdown
    std::thread countFromTwenty(countdown);

    // Wait for thread 2 to finish
    countFromTwenty.join();

    return 0;
}
